# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

OUT = "/Users/nals_macbook_116/Desktop/clone-web/kynghenguyenminh/html"

def acc(bid, items):
    """items = [(tiêu đề, mô tả html)]"""
    li = []
    for i, (t, d) in enumerate(items, 1):
        li.append(f'''      <li class="acc__item">
        <button class="acc__btn t-small" aria-expanded="false" aria-controls="{bid}-{i}">
          <span class="acc__title">{t}</span><span class="acc__icon" aria-hidden="true"></span>
        </button>
        <div class="acc__panel" id="{bid}-{i}" role="region"><div class="acc__desc t-small"><p>{d}</p></div></div>
      </li>''')
    return '<ul class="acc" data-multi="false">\n' + "\n".join(li) + '\n    </ul>'

def img(src, w, h, alt="", eager=False):
    l = 'fetchpriority="high"' if eager else 'loading="lazy"'
    return f'<img src="{src}" alt="{alt}" width="{w}" height="{h}" {l} decoding="async">'

W = lambda rel, html: open(os.path.join(OUT, rel), "w", encoding="utf-8").write(html)

# ══════════════════════════════════════════════════════════════════ TRANG CHỦ
home_c1 = acc("acc-co-khi", [
 ("Cắt tôn, thép tấm", "Cắt CNC / plasma theo file DXF, DWG hoặc bản vẽ tay. Đường cắt gọn, hạn chế ba via, nhận cả chi tiết lẻ lẫn lô sản xuất."),
 ("Chấn – đột – tạo hình", "Chấn định hình tấm, đột lỗ và dập chi tiết theo dưỡng. Kích thước được kiểm tra đối chiếu bản vẽ trước khi chuyển công đoạn."),
 ("Hàn kết cấu (MIG / TIG / que)", "Hàn khung máy, giá đỡ, kết cấu thép và chi tiết inox. Mối hàn được mài và làm sạch trước khi sang xử lý bề mặt."),
 ("Tiện – phay CNC", "Gia công chi tiết máy, bạc, trục, mặt bích và phụ tùng thay thế theo mẫu hoặc bản vẽ."),
 ("Gia công theo bản vẽ", "Nhận bản vẽ 2D/3D, tư vấn vật liệu và phương án gia công hợp lý về chi phí trước khi báo giá."),
])
home_c2 = acc("acc-son", [
 ("Xử lý bề mặt", "Tẩy dầu mỡ, tẩy gỉ và làm sạch bề mặt — bước quyết định độ bám của lớp sơn về sau."),
 ("Phốt phát hoá", "Tạo lớp phốt phát chống ăn mòn, tăng độ bám dính giữa kim loại và lớp bột sơn."),
 ("Phun sơn tĩnh điện", "Phun bột bằng súng tĩnh điện, phủ đều cả góc cạnh và mặt trong, không chảy sơn, không loang màu."),
 ("Sấy định hình", "Sấy trong lò để bột nóng chảy và bám chắc, cho lớp phủ cứng, chịu va đập và trầy xước tốt hơn sơn nước."),
 ("Màu sắc &amp; bề mặt", "Sơn theo bảng màu RAL hoặc mẫu màu do khách gửi; bề mặt bóng, mờ, nhăn hoặc vân theo yêu cầu."),
])
home_c3 = acc("acc-them", [
 ("Tư vấn vật liệu &amp; bản vẽ", "Rà lại kích thước, đề xuất vật liệu và phương án gia công tiết kiệm trước khi chốt đơn hàng."),
 ("Lắp ráp cụm chi tiết", "Lắp ráp thành cụm hoàn chỉnh sau khi sơn, giao đến xưởng là dùng được ngay."),
 ("Đóng gói – bảo quản", "Bọc lót chống trầy lớp sơn, đóng kiện theo số lượng và ký hiệu do khách quy định."),
 ("Giao hàng tận xưởng", "Giao trong khu vực Bình Dương, Thành phố Hồ Chí Minh và Đồng Nai theo lịch thống nhất với khách hàng."),
 ("Sửa chữa – sơn lại", "Nhận sơn lại khung, tủ, chi tiết đã qua sử dụng: bóc lớp sơn cũ, xử lý bề mặt và phủ lớp mới."),
])

home_body = f'''<section class="sec t-black h-small s-home-0">
  <div class="sec-bg">{img("images/hero-xuong.jpg",2000,1125,"Hàn kết cấu thép tại xưởng",eager=True)}<div class="sec-bg__overlay"></div></div>
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-home-h1"><div class="rte"><div class="scaled"><h1><strong>GIA CÔNG CƠ KHÍ</strong></h1></div><div class="scaled"><h1><strong>&amp; SƠN TĨNH ĐIỆN</strong></h1></div><div class="scaled"><h1><strong>THEO YÊU CẦU</strong><span class="c-white"><strong>.</strong></span></h1></div></div></div>
    <div class="fe b-home-eyebrow"><div class="rte"><h4><span class="c-white"><strong>KỸ NGHỆ NGUYỄN MINH</strong></span></h4></div></div>
    <div class="fe b-home-lead"><div class="rte"><p class="t-large">Cắt, chấn, hàn, tiện phay CNC và sơn tĩnh điện trọn gói cho kết cấu thép, khung máy, vỏ tủ và chi tiết cơ khí — nhận gia công theo bản vẽ hoặc mẫu.</p></div></div>
    <div class="fe b-home-cta"><a class="btn" href="lien-he/index.html">NHẬN BÁO GIÁ</a></div>
    </div>
  </div>
</section>

<section class="sec t-black-bold h-medium s-home-1">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-home-intro-img">{img("images/gioi-thieu-tong-quan.jpg",1400,1750,"Dây chuyền gia công trong nhà xưởng")}</div>
    <div class="fe b-home-intro-h3"><div class="rte"><h3><strong>Kỹ Nghệ Nguyễn Minh — xưởng cơ khí và sơn tĩnh điện trọn gói</strong></h3></div></div>
    <div class="fe b-home-intro-p"><div class="rte"><p><strong>Công ty TNHH Kỹ Nghệ Nguyễn Minh nhận gia công cơ khí và sơn tĩnh điện cho nhà máy, xưởng sản xuất và nhà thầu trong khu vực Bình Dương. Từ tấm tôn, thép hộp hay một bản vẽ chi tiết, chúng tôi cắt – chấn – hàn – hoàn thiện rồi phủ sơn tĩnh điện ngay trong cùng một xưởng, nên chi tiết không phải chạy qua nhiều nơi và chất lượng được kiểm soát ở từng công đoạn.</strong></p></div></div>
    </div>
  </div>
</section>

<section class="sec t-white h-medium s-home-2">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-home-c1-img">{img("images/dv-co-khi.jpg",1200,1200,"Hàn chi tiết cơ khí")}</div>
    <div class="fe b-home-c1-h4"><div class="rte"><h4>GIA CÔNG CƠ KHÍ</h4></div></div>
    <div class="fe b-home-c1-acc">{home_c1}</div>
    <div class="fe b-home-c2-img">{img("images/dv-son-tinh-dien.jpg",1200,1200,"Phun sơn tĩnh điện trong buồng sơn")}</div>
    <div class="fe b-home-c2-h4"><div class="rte"><h4>SƠN TĨNH ĐIỆN</h4></div></div>
    <div class="fe b-home-c2-acc">{home_c2}</div>
    <div class="fe b-home-c3-img">{img("images/dv-kem-theo.jpg",1200,1200,"Chi tiết cơ khí thành phẩm")}</div>
    <div class="fe b-home-c3-h4"><div class="rte"><h4>DỊCH VỤ KÈM THEO</h4></div></div>
    <div class="fe b-home-c3-acc">{home_c3}</div>
    </div>
  </div>
</section>'''

W("index.html", page("", "home.css",
  "Gia công cơ khí &amp; sơn tĩnh điện Bình Dương | CÔNG TY TNHH KỸ NGHỆ NGUYỄN MINH",
  "Kỹ Nghệ Nguyễn Minh nhận gia công cơ khí và sơn tĩnh điện theo bản vẽ: cắt CNC, chấn, hàn kết cấu, tiện phay, xử lý bề mặt và phủ sơn tĩnh điện. Khu vực Bình Dương – TP. Hồ Chí Minh – Đồng Nai.",
  "TRANG CHỦ", home_body))
print("index.html")
