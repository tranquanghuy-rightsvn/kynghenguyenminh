BỘ SINH TRANG — website Kỹ Nghệ Nguyễn Minh
===========================================
6 file index.html trong site được sinh ra từ các script này, nhờ vậy phần
header/menu/footer luôn giống hệt nhau trên mọi trang.

  common.py   header, menu mobile, footer, thông tin công ty, khung <head>
  build.py    trang chủ            -> index.html
  build2.py   giới thiệu, dịch vụ  -> gioi-thieu/, dich-vu/
  build3.py   quy trình, dự án, liên hệ -> quy-trinh/, du-an/, lien-he/

Cách dùng: sửa nội dung trong script rồi chạy
  python3 build.py && python3 build2.py && python3 build3.py

Đường dẫn đích được khai báo ở biến OUT trong từng file — chỉnh lại nếu
di chuyển thư mục website.

Sửa nội dung nhỏ, lẻ tẻ thì cứ sửa thẳng file .html cũng được; nhưng nhớ
là chạy lại script sẽ ghi đè các sửa đổi đó.
CSS nằm ở css/*.css, không do script sinh ra — sửa trực tiếp.
