# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
OUT = "/Users/nals_macbook_116/Desktop/clone-web/kynghenguyenminh/html/selectpowdercoating-com-clone"
P = "../"
def img(src,w,h,alt="",eager=False):
    l='fetchpriority="high"' if eager else 'loading="lazy"'
    return f'<img src="{P}images/{src}" alt="{alt}" width="{w}" height="{h}" {l} decoding="async">'
def W(rel,html):
    os.makedirs(os.path.dirname(os.path.join(OUT,rel)),exist_ok=True)
    open(os.path.join(OUT,rel),"w",encoding="utf-8").write(html)

DIV = lambda d: (f'<svg class="sec-divider" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">'
                 f'<path class="sec-divider__fill" d="{d[0]}"/><path class="sec-divider__line" d="{d[1]}" '
                 f'fill="none" vector-effect="non-scaling-stroke"/></svg>')
ZIG1 = ("M-101.65,0 L-76.38,100 L-0.55,0 L24.72,100 L100.55,0 L125.82,100 L201.65,0 L100,100 L0,100 Z",
        "M-101.65,0 L-76.38,100 L-0.55,0 L24.72,100 L100.55,0 L125.82,100 L201.65,0")
ZIG2 = ("M-100.6,0 L-25.3,100 L-0.2,0 L75.1,100 L100.2,0 L175.5,100 L200.6,0 L100,100 L0,100 Z",
        "M-100.6,0 L-25.3,100 L-0.2,0 L75.1,100 L100.2,0 L175.5,100 L200.6,0")
ZIG3 = ("M-101.8,100 L-76.53,0 L-0.7,100 L24.57,0 L100.4,100 L125.67,0 L201.5,0 L100,100 L0,100 Z",
        "M-101.8,100 L-76.53,0 L-0.7,100 L24.57,0 L100.4,100 L125.67,0 L201.5,0")
ZIG4 = ("M-100.35,0 L-75.25,100 L0.05,0 L25.15,100 L100.45,0 L125.55,100 L200.85,0 L100,100 L0,100 Z",
        "M-100.35,0 L-75.25,100 L0.05,0 L25.15,100 L100.45,0 L125.55,100 L200.85,0")

NOTE_STOCK = "<!-- ẢNH MINH HOẠ (kho ảnh Unsplash) — thay bằng ảnh chụp thật của công ty khi có -->"

# ═════════════════════════════════════════════════════════════════ GIỚI THIỆU
gt_imgs = [
 ("xuong-01.jpg",1400,933,"Toàn cảnh khu vực sản xuất"),
 ("xuong-02.jpg",1200,900,"Khu vực máy gia công trong xưởng"),
 ("xuong-03.jpg",1200,900,"Máy phay CNC đang gia công chi tiết"),
 ("xuong-04.jpg",1000,1250,"Thợ hàn thi công kết cấu thép"),
 ("xuong-05.jpg",1200,900,"Bàn thao tác và chi tiết đang gia công"),
 ("xuong-06.jpg",1200,800,"Cuộn thép nguyên liệu"),
 ("xuong-07.jpg",1000,1250,"Cắt tôn bằng máy CNC"),
]
def _gt(i, s, w, h, a):
    anchor = ' id="nha-xuong"' if i == 1 else ''
    return '<div class="fe b-gt-img%d"%s>%s</div>' % (i, anchor, img(s, w, h, a))
gt_blocks = "\n    ".join(_gt(i, *t) for i, t in enumerate(gt_imgs, 1))

gt_body = f'''<section class="sec t-white-bold h-medium s-gioi-thieu-0">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-gt-h2" id="ve-cong-ty"><div class="rte"><h2 class="center">{COMPANY}</h2></div></div>
    <div class="fe b-gt-lead"><div class="rte"><p class="t-small">Xưởng cơ khí và sơn tĩnh điện đặt tại Khu phố Khánh Long, Phường Tân Khánh — khu vực Bình Dương trước đây, nay thuộc Thành phố Hồ Chí Minh. Chúng tôi nhận gia công theo bản vẽ cho nhà máy, xưởng sản xuất, nhà thầu cơ khí và khách hàng lẻ trong vùng.</p></div></div>
    {NOTE_STOCK}
    {gt_blocks}
    <div class="fe b-gt-body" id="nang-luc"><div class="rte"><p class="t-small">Kỹ Nghệ Nguyễn Minh hoạt động trong lĩnh vực gia công cơ khí và sơn tĩnh điện. Toàn bộ công đoạn — từ pha cắt phôi, chấn, hàn, hoàn thiện cho đến xử lý bề mặt và phủ sơn — được thực hiện trong cùng một xưởng, nên chi tiết không phải di chuyển qua nhiều nơi và thời gian giao hàng được rút ngắn.</p><p class="t-small">Chúng tôi làm việc trực tiếp trên bản vẽ của khách hàng. Trước khi báo giá, bộ phận kỹ thuật rà lại kích thước, chọn vật liệu và đề xuất phương án gia công hợp lý về chi phí; những điểm chưa rõ trên bản vẽ đều được xác nhận lại với khách trước khi cắt phôi.</p><p class="t-small"><strong>Năng lực nhận hàng</strong></p><ul data-rte-list="default"><li class="t-small"><p class="t-small">Cắt – chấn – đột tôn, thép tấm theo file DXF/DWG hoặc bản vẽ tay</p></li><li class="t-small"><p class="t-small">Hàn kết cấu thép, khung máy, giá đỡ, vỏ tủ và vỏ thiết bị</p></li><li class="t-small"><p class="t-small">Tiện – phay chi tiết máy, phụ tùng thay thế theo mẫu</p></li><li class="t-small"><p class="t-small">Sơn tĩnh điện: xử lý bề mặt, phốt phát, phun bột, sấy định hình</p></li><li class="t-small"><p class="t-small">Vật liệu thường dùng: thép CT3/SS400, tôn mạ kẽm, inox 201/304, nhôm</p></li><li class="t-small"><p class="t-small">Lắp ráp cụm chi tiết, đóng gói và giao hàng tận xưởng</p></li></ul><p class="t-small">Khách hàng của chúng tôi gồm các xưởng sản xuất, đơn vị thi công cơ khí và nhà thầu trong khu vực Bình Dương, Thành phố Hồ Chí Minh và Đồng Nai. Với đơn hàng lặp lại, chúng tôi lưu dưỡng và thông số sơn để các lô sau đồng nhất với lô đầu tiên.</p><p class="t-small">Quý khách cần báo giá, vui lòng gửi bản vẽ hoặc hình ảnh chi tiết về <a href="mailto:{EMAIL}">{EMAIL}</a>.</p></div></div>
    </div>
  </div>
</section>'''
W("gioi-thieu/index.html", page(P,"gioi-thieu.css",
  "Giới thiệu công ty &amp; nhà xưởng — KỸ NGHỆ NGUYỄN MINH",
  "Giới thiệu Công ty TNHH Kỹ Nghệ Nguyễn Minh: xưởng gia công cơ khí và sơn tĩnh điện tại Phường Tân Khánh, khu vực Bình Dương. Năng lực cắt, chấn, hàn, tiện phay và sơn tĩnh điện khép kín.",
  "GIỚI THIỆU", gt_body))

# ═══════════════════════════════════════════════════════════════════ DỊCH VỤ
dv_body = f'''<section class="sec t-white h-custom s-dich-vu-0">
  {DIV(ZIG3)}
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-dv-hero">{img("co-khi-hero.jpg",2000,1000,"Cắt kim loại bằng máy CNC",eager=True)}</div>
    <div class="fe b-dv-h3" id="co-khi"><div class="rte"><div class="scaled"><h3>Gia công cơ khí chính xác theo bản vẽ</h3></div></div></div>
    <div class="fe b-dv-text"><div class="rte"><p>Chúng tôi nhận gia công chi tiết đơn lẻ lẫn lô sản xuất: cắt tôn và thép tấm theo file DXF/DWG, chấn định hình, đột lỗ, hàn kết cấu và tiện phay chi tiết máy. Mỗi công đoạn đều đối chiếu với bản vẽ gốc, kích thước được kiểm tra trước khi chuyển sang bước kế tiếp.</p><p>Vật liệu thường dùng gồm thép CT3, SS400, tôn mạ kẽm, inox 201/304 và nhôm. Nếu khách hàng chưa chốt vật liệu, bộ phận kỹ thuật sẽ tư vấn phương án cân đối giữa độ bền, khối lượng và chi phí trước khi báo giá.</p><p>Với đơn hàng cần hoàn thiện bề mặt, chi tiết sau khi hàn sẽ được mài sạch mối hàn rồi chuyển thẳng sang khu vực xử lý bề mặt và sơn tĩnh điện trong cùng xưởng — không phải gửi ra ngoài, rút ngắn được thời gian và tránh trầy xước khi vận chuyển.</p></div></div>
    <div class="fe b-dv-img2">{img("co-khi-02.jpg",1200,1500,"Chi tiết cơ khí sau gia công")}</div>
    <div class="fe b-dv-h3b" id="dich-vu-kem-theo"><div class="rte"><h3>DỊCH VỤ KÈM THEO</h3></div></div>
    <div class="fe b-dv-textb"><div class="rte"><p><strong>Tư vấn vật liệu &amp; bản vẽ</strong></p><p>Rà soát kích thước, dung sai và đề xuất phương án gia công tiết kiệm trước khi chốt đơn hàng.</p><p><strong>Lắp ráp cụm chi tiết</strong></p><p>Lắp thành cụm hoàn chỉnh sau khi sơn để khách nhận về là lắp đặt được ngay.</p><p><strong>Đóng gói &amp; bảo quản</strong></p><p>Bọc lót chống trầy lớp sơn, đóng kiện theo số lượng và ký hiệu do khách quy định.</p><p><strong>Giao hàng tận xưởng</strong></p><p>Giao trong khu vực Bình Dương, Thành phố Hồ Chí Minh và Đồng Nai theo lịch đã thống nhất.</p><p><strong>Sửa chữa &amp; sơn lại</strong></p><p>Nhận bóc lớp sơn cũ, xử lý bề mặt và phủ mới cho khung, tủ, chi tiết đã qua sử dụng.</p></div></div>
    </div>
  </div>
</section>

<section class="sec t-black-bold h-medium s-dich-vu-1">
  {DIV(ZIG1)}
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-dv-img3">{img("son-tinh-dien-02.jpg",1200,1500,"Phun sơn tĩnh điện lên chi tiết kim loại")}</div>
    <div class="fe b-dv-sticky fe--sticky" id="son-tinh-dien"><div class="rte"><div class="scaled"><p><span class="c-accent">SƠN TĨNH ĐIỆN</span></p></div><div class="scaled"><p><span class="c-accent">QUY TRÌNH &amp; NĂNG LỰC</span></p></div><p></p><p>XỬ LÝ BỀ MẶT: tẩy dầu mỡ – tẩy gỉ – phốt phát hoá</p><p>PHUN BỘT: súng tĩnh điện, phủ đều cả góc cạnh và mặt trong</p><p>SẤY ĐỊNH HÌNH: sấy trong lò cho lớp phủ cứng, bám chắc</p><p>MÀU SƠN: theo bảng màu RAL hoặc mẫu màu của khách hàng</p><p>BỀ MẶT: bóng, mờ, nhăn, vân</p><p>NHẬN CẢ: hàng mới và hàng sơn lại</p></div></div>
    </div>
  </div>
</section>

<section class="sec t-white h-medium s-dich-vu-2">
  {DIV(("M-100,0 L-50,100 L0,0 L50,100 L100,0 L150,100 L200,0 L100,100 L0,100 Z","M-100,0 L-50,100 L0,0 L50,100 L100,0 L150,100 L200,0"))}
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-dv-nganh" id="nganh-hang"><div class="rte"><h3 class="center">NGÀNH HÀNG PHỤC VỤ</h3><p class="t-large"></p><p class="t-large center"><strong>Kết cấu thép &amp; xây dựng</strong></p><p class="t-small center">Khung nhà xưởng, cầu thang, lan can, sàn thao tác, giá đỡ và chi tiết kết cấu.</p><p class="t-large center"><strong>Cơ khí chế tạo máy</strong></p><p class="t-small center">Khung máy, vỏ máy, bàn thao tác, băng tải, chi tiết máy và phụ tùng thay thế.</p><p class="t-large center"><strong>Điện &amp; tủ bảng điện</strong></p><p class="t-small center">Vỏ tủ điện, hộp kỹ thuật, máng cáp, giá đỡ thiết bị điện.</p><p class="t-large center"><strong>Nội thất kim loại</strong></p><p class="t-small center">Khung bàn ghế, kệ hàng, tủ locker, vách ngăn và chi tiết trang trí kim loại.</p><p class="t-large center"><strong>Thiết bị phụ trợ nhà xưởng</strong></p><p class="t-small center">Xe đẩy, pallet thép, khay đựng linh kiện, giá kê hàng, thùng chứa.</p><p class="t-large center"><strong>Quảng cáo &amp; trang trí</strong></p><p class="t-small center">Khung biển hiệu, chữ nổi, chi tiết trang trí cần lớp sơn bền màu ngoài trời.</p></div></div>
    </div>
  </div>
</section>'''
W("dich-vu/index.html", page(P,"dich-vu.css",
  "Dịch vụ gia công cơ khí &amp; sơn tĩnh điện — KỸ NGHỆ NGUYỄN MINH",
  "Dịch vụ cắt CNC, chấn, đột, hàn kết cấu, tiện phay và sơn tĩnh điện trọn gói. Vật liệu thép CT3, SS400, tôn mạ kẽm, inox, nhôm. Nhận gia công theo bản vẽ tại khu vực Bình Dương.",
  "DỊCH VỤ", dv_body))
print("gioi-thieu, dich-vu")
