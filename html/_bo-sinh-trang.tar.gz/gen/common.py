# -*- coding: utf-8 -*-
"""Khối dùng chung: header, mobile nav, footer."""

COMPANY = "CÔNG TY TNHH KỸ NGHỆ NGUYỄN MINH"
SHORT   = "KỸ NGHỆ NGUYỄN MINH"
ADDR    = "Số 110, Tổ 2, Khu phố Khánh Long, Phường Tân Khánh, Thành phố Hồ Chí Minh, Việt Nam"
ADDR_S  = "Số 110, Tổ 2, KP. Khánh Long, P. Tân Khánh, TP. Hồ Chí Minh"
MST     = "3703360971"
EMAIL   = "Nguyenminheng.ltd@gmail.com"

# (nhãn, đường dẫn) — đường dẫn tương đối tính từ gốc site
NAV = [
    ("link",   "TRANG CHỦ", "index.html", []),
    ("folder", "GIỚI THIỆU", None, [
        ("Về công ty",            "gioi-thieu/index.html"),
        ("Nhà xưởng & thiết bị",  "gioi-thieu/index.html#nha-xuong"),
        ("Năng lực sản xuất",     "gioi-thieu/index.html#nang-luc"),
    ]),
    ("folder", "DỊCH VỤ", None, [
        ("Gia công cơ khí",   "dich-vu/index.html#co-khi"),
        ("Sơn tĩnh điện",     "dich-vu/index.html#son-tinh-dien"),
        ("Dịch vụ kèm theo",  "dich-vu/index.html#dich-vu-kem-theo"),
        ("Quy trình gia công","quy-trinh/index.html"),
    ]),
    ("folder", "DỰ ÁN", None, [
        ("Sản phẩm đã thực hiện", "du-an/index.html"),
        ("Ngành hàng phục vụ",    "dich-vu/index.html#nganh-hang"),
    ]),
]
CTA = ("NHẬN BÁO GIÁ", "lien-he/index.html")

FOOTER_LINKS = [
    ("Gia công cơ khí", "dich-vu/index.html#co-khi"),
    ("Sơn tĩnh điện",   "dich-vu/index.html#son-tinh-dien"),
    ("Quy trình",       "quy-trinh/index.html"),
    ("Nhà xưởng",       "gioi-thieu/index.html#nha-xuong"),
    ("Sản phẩm",        "du-an/index.html"),
    ("Liên hệ",         "lien-he/index.html"),
]

TAGLINE = ("Gia công cơ khí  ·  Sơn tĩnh điện  ·  Kết cấu thép  ·  Gia công theo bản vẽ"
           "  ·  Khu vực Bình Dương – TP. Hồ Chí Minh – Đồng Nai")


def logo(p, cls="header__logo", href="index.html"):
    return f'''<a class="{cls}" href="{p}{href}" aria-label="{SHORT} — trang chủ">
      <span class="logo">
        <span class="logo__mark" aria-hidden="true">NM</span>
        <span class="logo__lines">
          <span class="logo__eyebrow">CÔNG TY TNHH</span>
          <span class="logo__name">KỸ NGHỆ NGUYỄN MINH</span>
          <span class="logo__tag">CƠ KHÍ · SƠN TĨNH ĐIỆN</span>
        </span>
      </span>
    </a>'''


def header(p, active):
    """p = tiền tố đường dẫn ('' hoặc '../'), active = nhãn mục đang mở."""
    out = [f'<header class="header">\n  <div class="header__inner">\n    {logo(p)}',
           '    <nav class="nav" aria-label="Điều hướng chính">']
    for i, (kind, label, href, children) in enumerate(NAV, 1):
        if kind == "link":
            act = ' nav__link--active' if label == active else ''
            cur = ' aria-current="page"' if label == active else ''
            out.append(f'        <div class="nav__item"><a class="nav__link{act}" '
                       f'href="{p}{href}"{cur}>{label}</a></div>')
        else:
            out.append('        <div class="nav__item nav__item--folder">')
            out.append(f'          <button class="nav__folder-btn" aria-expanded="false" '
                       f'aria-controls="folder-{i}">{label}</button>')
            out.append(f'          <div class="nav__folder" id="folder-{i}">')
            for t, h in children:
                out.append(f'            <a href="{p}{h}">{t}</a>')
            out.append('          </div>\n        </div>')
    out.append('    </nav>')
    out.append(f'    <a class="btn header__cta" href="{p}{CTA[1]}">{CTA[0]}</a>')
    out.append('    <button class="burger" aria-label="Menu" aria-expanded="false" aria-controls="mobile-nav">')
    out.append('      <span></span><span></span><span></span>\n    </button>')
    out.append('  </div>\n</header>')

    m = ['<div class="mobile-nav" id="mobile-nav">']
    for i, (kind, label, href, children) in enumerate(NAV, 1):
        if kind == "link":
            m.append(f'      <a href="{p}{href}">{label}</a>')
        else:
            m.append('      <div class="m-folder">')
            m.append(f'        <button class="m-folder__btn" aria-expanded="false" '
                     f'aria-controls="m-folder-{i}">{label}</button>')
            m.append(f'        <div class="m-folder__list" id="m-folder-{i}"><div>')
            for t, h in children:
                m.append(f'          <a href="{p}{h}">{t}</a>')
            m.append('        </div></div>\n      </div>')
    m.append(f'      <a href="{p}{CTA[1]}">{CTA[0]}</a>')
    m.append('</div>')
    return "\n".join(out) + "\n" + "\n".join(m)


def footer(p):
    links = '<span class="c-accent">   |   </span>'.join(
        f'<a href="{p}{h}"><span class="c-accent">{t}</span></a>' for t, h in FOOTER_LINKS)
    return f'''<section class="sec t-black h-small s-footer-0 footer">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-ft-logo"><div class="flogo">
      <span class="flogo__mark" aria-hidden="true">NM</span>
      <span class="flogo__name">KỸ NGHỆ NGUYỄN MINH</span>
      <span class="flogo__sub">CƠ KHÍ · SƠN TĨNH ĐIỆN</span>
    </div></div>
    <div class="fe b-ft-addr"><div class="rte"><pre class="center"><code>{COMPANY}  |  {ADDR_S}
MST: {MST}  |  <a href="mailto:{EMAIL}">{EMAIL}</a></code></pre></div></div>
    <div class="fe b-ft-links"><div class="rte"><p class="t-small center">{links}</p><pre class="center"><code>{TAGLINE}</code></pre><p></p></div></div>
    <div class="fe b-ft-band"><img src="{p}images/footer-band.jpg" alt="" width="1920" height="480" loading="lazy" decoding="async"></div>
    </div>
  </div>
</section>'''


def page(path_prefix, css, title, desc, active, body):
    return f'''<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="icon" href="{path_prefix}images/favicon.svg" type="image/svg+xml">
<link rel="preload" as="font" type="font/woff2" href="{path_prefix}fonts/manrope-500.woff2" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="{path_prefix}fonts/poppins-400.woff2" crossorigin>
<link rel="stylesheet" href="{path_prefix}css/main.css">
<link rel="stylesheet" href="{path_prefix}css/{css}">
</head>
<body>
<a class="skip-link" href="#main">Bỏ qua, tới nội dung chính</a>
{header(path_prefix, active)}
<main id="main">
{body}
</main>
{footer(path_prefix)}
<script src="{path_prefix}js/main.js" defer></script>
</body>
</html>
'''
