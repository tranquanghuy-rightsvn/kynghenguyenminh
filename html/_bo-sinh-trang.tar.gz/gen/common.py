# -*- coding: utf-8 -*-
"""Khối dùng chung: header, mobile nav, footer."""

COMPANY = "CÔNG TY TNHH KỸ NGHỆ NGUYỄN MINH"
SHORT   = "KỸ NGHỆ NGUYỄN MINH"
ADDR    = "Số 110, Tổ 2, Khu phố Khánh Long, Phường Tân Khánh, Thành phố Hồ Chí Minh, Việt Nam"
ADDR_S  = "Số 110, Tổ 2, KP. Khánh Long, P. Tân Khánh, TP. Hồ Chí Minh"
MST     = "3703360971"
EMAIL   = "Nguyenminheng.ltd@gmail.com"

# (nhãn, đường dẫn) — đường dẫn tương đối tính từ gốc site
NAV = [
    ("link",   "TRANG CHỦ", "index.html", []),
    ("folder", "GIỚI THIỆU", None, [
        ("Về công ty",            "gioi-thieu/index.html"),
        ("Nhà xưởng & thiết bị",  "gioi-thieu/index.html#nha-xuong"),
        ("Năng lực sản xuất",     "gioi-thieu/index.html#nang-luc"),
    ]),
    ("folder", "DỊCH VỤ", None, [
        ("Gia công cơ khí",   "dich-vu/index.html#co-khi"),
        ("Sơn tĩnh điện",     "dich-vu/index.html#son-tinh-dien"),
        ("Dịch vụ kèm theo",  "dich-vu/index.html#dich-vu-kem-theo"),
        ("Quy trình gia công","quy-trinh/index.html"),
    ]),
    ("folder", "DỰ ÁN", None, [
        ("Sản phẩm đã thực hiện", "du-an/index.html"),
        ("Ngành hàng phục vụ",    "dich-vu/index.html#nganh-hang"),
    ]),
]
CTA = ("NHẬN BÁO GIÁ", "lien-he/index.html")

FOOTER_LINKS = [
    ("Gia công cơ khí", "dich-vu/index.html#co-khi"),
    ("Sơn tĩnh điện",   "dich-vu/index.html#son-tinh-dien"),
    ("Quy trình",       "quy-trinh/index.html"),
    ("Nhà xưởng",       "gioi-thieu/index.html#nha-xuong"),
    ("Sản phẩm",        "du-an/index.html"),
    ("Liên hệ",         "lien-he/index.html"),
]

TAGLINE = ("Gia công cơ khí  ·  Sơn tĩnh điện  ·  Kết cấu thép  ·  Gia công theo bản vẽ"
           "  ·  Khu vực Bình Dương – TP. Hồ Chí Minh – Đồng Nai")


def logo(p, cls="header__logo", href="index.html"):
    return f'''<a class="{cls}" href="{p}{href}" aria-label="{SHORT} — trang chủ">
      <span class="logo">
        <span class="logo__mark" aria-hidden="true">NM</span>
        <span class="logo__lines">
          <span class="logo__eyebrow">CÔNG TY TNHH</span>
          <span class="logo__name">KỸ NGHỆ NGUYỄN MINH</span>
          <span class="logo__tag">CƠ KHÍ · SƠN TĨNH ĐIỆN</span>
        </span>
      </span>
    </a>'''


def header(p, active):
    """p = tiền tố đường dẫn ('' hoặc '../'), active = nhãn mục đang mở."""
    out = [f'<header class="header">\n  <div class="header__inner">\n    {logo(p)}',
           '    <nav class="nav" aria-label="Điều hướng chính">']
    for i, (kind, label, href, children) in enumerate(NAV, 1):
        if kind == "link":
            act = ' nav__link--active' if label == active else ''
            cur = ' aria-current="page"' if label == active else ''
            out.append(f'        <div class="nav__item"><a class="nav__link{act}" '
                       f'href="{p}{href}"{cur}>{label}</a></div>')
        else:
            out.append('        <div class="nav__item nav__item--folder">')
            out.append(f'          <button class="nav__folder-btn" aria-expanded="false" '
                       f'aria-controls="folder-{i}">{label}</button>')
            out.append(f'          <div class="nav__folder" id="folder-{i}">')
            for t, h in children:
                out.append(f'            <a href="{p}{h}">{t}</a>')
            out.append('          </div>\n        </div>')
    out.append('    </nav>')
    out.append(f'    <a class="btn header__cta" href="{p}{CTA[1]}">{CTA[0]}</a>')
    out.append('    <button class="burger" aria-label="Menu" aria-expanded="false" aria-controls="mobile-nav">')
    out.append('      <span></span><span></span><span></span>\n    </button>')
    out.append('  </div>\n</header>')

    m = ['<div class="mobile-nav" id="mobile-nav">']
    for i, (kind, label, href, children) in enumerate(NAV, 1):
        if kind == "link":
            m.append(f'      <a href="{p}{href}">{label}</a>')
        else:
            m.append('      <div class="m-folder">')
            m.append(f'        <button class="m-folder__btn" aria-expanded="false" '
                     f'aria-controls="m-folder-{i}">{label}</button>')
            m.append(f'        <div class="m-folder__list" id="m-folder-{i}"><div>')
            for t, h in children:
                m.append(f'          <a href="{p}{h}">{t}</a>')
            m.append('        </div></div>\n      </div>')
    m.append(f'      <a href="{p}{CTA[1]}">{CTA[0]}</a>')
    m.append('</div>')
    return "\n".join(out) + "\n" + "\n".join(m)


MAPQ = ("S%E1%BB%91%20110%20Khu%20ph%E1%BB%91%20Kh%C3%A1nh%20Long%2C%20"
        "T%C3%A2n%20Kh%C3%A1nh%2C%20B%C3%ACnh%20D%C6%B0%C6%A1ng")

# Icon dạng SVG nội tuyến (không dùng thư viện icon)
ICON = {
 "diachi": '<path d="M12 21s-7-6.3-7-11a7 7 0 1 1 14 0c0 4.7-7 11-7 11z"/><circle cx="12" cy="10" r="2.6"/>',
 "mst":    '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h6"/>',
 "email":  '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 6 8.5-6"/>',
 "khuvuc": '<circle cx="12" cy="12" r="9"/><path d="M3.2 9h17.6M3.2 15h17.6"/><path d="M12 3c2.5 2.6 3.8 5.7 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.7-3.8-9S9.5 5.6 12 3z"/>',
 "hangmuc":'<path d="M3 7.5 12 3l9 4.5-9 4.5z"/><path d="M3 12.5 12 17l9-4.5"/><path d="M3 17 12 21.5 21 17"/>',
}

def _row(icon, html):
    return (f'      <li class="fcontact__row">'
            f'<svg class="fcontact__ico" viewBox="0 0 24 24" aria-hidden="true">{ICON[icon]}</svg>'
            f'<span class="fcontact__txt">{html}</span></li>')


def footer(p):
    links = "".join(f'<a href="{p}{h}">{t}</a>' for t, h in FOOTER_LINKS)
    rows = "\n".join([
        _row("diachi", f'Số 110, Tổ 2, Khu phố Khánh Long<br>Phường Tân Khánh, Thành phố Hồ Chí Minh'),
        # Chưa có số điện thoại. Khi có, bỏ chú thích dòng dưới và điền số:
        # _row("dienthoai", '<a href="tel:+84...">0xxx xxx xxx</a>'),
        _row("mst",    f'Mã số thuế: {MST}'),
        _row("email",  f'<a href="mailto:{EMAIL}">{EMAIL}</a>'),
        _row("khuvuc", 'Bình Dương · Thành phố Hồ Chí Minh · Đồng Nai'),
        _row("hangmuc",'Gia công cơ khí · Sơn tĩnh điện'),
    ])
    return f'''<footer class="site-footer">
  <div class="site-footer__inner">
    <div class="site-footer__col">
      <a class="flogo" href="{p}index.html" aria-label="{SHORT} — trang chủ">
        <span class="flogo__mark" aria-hidden="true">NM</span>
        <span class="flogo__lines">
          <span class="flogo__name">KỸ NGHỆ NGUYỄN MINH</span>
          <span class="flogo__sub">CƠ KHÍ · SƠN TĨNH ĐIỆN</span>
        </span>
      </a>
      <div class="site-footer__rule" role="separator"></div>
      <ul class="fcontact">
{rows}
      </ul>
    </div>
    <div class="site-footer__map">
      <iframe title="Bản đồ vị trí xưởng {SHORT}" src="https://www.google.com/maps?q={MAPQ}&amp;output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
  </div>
  <div class="site-footer__bar">
    <nav class="site-footer__nav" aria-label="Liên kết chân trang">{links}</nav>
    <p class="site-footer__copy">© 2026 {COMPANY}</p>
  </div>
</footer>'''


def page(path_prefix, css, title, desc, active, body):
    return f'''<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="icon" href="{path_prefix}images/favicon.svg" type="image/svg+xml">
<link rel="preload" as="font" type="font/woff2" href="{path_prefix}fonts/be-vietnam-pro-700-vietnamese.woff2" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="{path_prefix}fonts/inter-400-vietnamese.woff2" crossorigin>
<link rel="stylesheet" href="{path_prefix}css/main.css">
<link rel="stylesheet" href="{path_prefix}css/{css}">
</head>
<body>
<a class="skip-link" href="#main">Bỏ qua, tới nội dung chính</a>
{header(path_prefix, active)}
<main id="main">
{body}
</main>
{footer(path_prefix)}
<script src="{path_prefix}js/main.js" defer></script>
</body>
</html>
'''
