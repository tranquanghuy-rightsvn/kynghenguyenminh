# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
OUT = "/Users/nals_macbook_116/Desktop/clone-web/kynghenguyenminh/html/selectpowdercoating-com-clone"
P = "../"
def img(src,w,h,alt="",eager=False):
    l='fetchpriority="high"' if eager else 'loading="lazy"'
    return f'<img src="{P}images/{src}" alt="{alt}" width="{w}" height="{h}" {l} decoding="async">'
def W(rel,html):
    os.makedirs(os.path.dirname(os.path.join(OUT,rel)),exist_ok=True)
    open(os.path.join(OUT,rel),"w",encoding="utf-8").write(html)
DIV = lambda d: (f'<svg class="sec-divider" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">'
                 f'<path class="sec-divider__fill" d="{d[0]}"/><path class="sec-divider__line" d="{d[1]}" '
                 f'fill="none" vector-effect="non-scaling-stroke"/></svg>')
ZIG2 = ("M-100.6,0 L-25.3,100 L-0.2,0 L75.1,100 L100.2,0 L175.5,100 L200.6,0 L100,100 L0,100 Z",
        "M-100.6,0 L-25.3,100 L-0.2,0 L75.1,100 L100.2,0 L175.5,100 L200.6,0")
ZIG4 = ("M-100.35,0 L-75.25,100 L0.05,0 L25.15,100 L100.45,0 L125.55,100 L200.85,0 L100,100 L0,100 Z",
        "M-100.35,0 L-75.25,100 L0.05,0 L25.15,100 L100.45,0 L125.55,100 L200.85,0")
NOTE_STOCK = "<!-- ẢNH MINH HOẠ (kho ảnh Unsplash) — thay bằng ảnh chụp thật của công ty khi có -->"
HR = '<div class="hr" role="separator"></div>'

# ═════════════════════════════════════════════════════════════════ QUY TRÌNH
STEPS = [
 ("01","Tiếp nhận bản vẽ &amp; báo giá","Nhận bản vẽ, mẫu hoặc hình ảnh chi tiết. Kỹ thuật rà lại kích thước, dung sai, chọn vật liệu rồi gửi báo giá kèm thời gian dự kiến."),
 ("02","Chuẩn bị vật tư &amp; pha phôi","Xuất vật tư theo đúng chủng loại và độ dày trong bản vẽ, tính toán pha phôi sao cho tiết kiệm tôn nhất."),
 ("03","Cắt CNC / plasma","Cắt theo file DXF, DWG. Đường cắt gọn, hạn chế ba via và biến dạng nhiệt."),
 ("04","Chấn – đột – tạo hình","Chấn định hình, đột lỗ theo dưỡng. Chi tiết đầu tiên của mỗi lô được đo kiểm trước khi chạy hàng loạt."),
 ("05","Hàn &amp; hoàn thiện mối hàn","Hàn MIG/TIG/que tuỳ vật liệu, sau đó mài phẳng và làm sạch mối hàn."),
 ("06","Xử lý bề mặt","Tẩy dầu mỡ, tẩy gỉ và phốt phát hoá — công đoạn quyết định độ bám của lớp sơn."),
 ("07","Sơn tĩnh điện &amp; sấy","Phun bột bằng súng tĩnh điện rồi sấy định hình trong lò cho lớp phủ cứng và bám chắc."),
 ("08","Kiểm tra – đóng gói – giao hàng","Kiểm màu, độ dày và độ bám lớp sơn, đếm đủ số lượng, bọc lót chống trầy rồi giao tận xưởng."),
]
steps_html = "".join(
 f'<p><strong>{n} · {t}</strong></p><p class="t-small">{d}</p>' for n,t,d in STEPS)

TABLE = [
 ("Cắt tôn – thép tấm (CNC / plasma)","Theo file DXF, DWG hoặc bản vẽ tay"),
 ("Chấn – đột – tạo hình","Chi tiết đơn lẻ đến lô sản xuất"),
 ("Hàn kết cấu","MIG · TIG · hàn que"),
 ("Tiện – phay CNC","Chi tiết máy, phụ tùng thay thế"),
 ("Vật liệu gia công","Thép CT3 / SS400, tôn mạ kẽm, inox 201/304, nhôm"),
 ("Xử lý bề mặt trước sơn","Tẩy dầu – tẩy gỉ – phốt phát hoá"),
 ("Sơn tĩnh điện","Bột sơn dùng trong nhà và ngoài trời"),
 ("Màu sơn","Bảng màu RAL hoặc mẫu màu của khách hàng"),
 ("Bề mặt hoàn thiện","Bóng · mờ · nhăn · vân"),
 ("Sấy định hình","Sấy trong lò sau khi phun bột"),
 ("Lắp ráp – đóng gói","Có, theo yêu cầu của khách hàng"),
 ("Khu vực giao hàng","Bình Dương · TP. Hồ Chí Minh · Đồng Nai"),
]
rows = []
for i,(l,r) in enumerate(TABLE,1):
    rows.append(f'    <div class="fe b-qt-tb-d{i} fe--top">{HR}</div>')
    rows.append(f'    <div class="fe b-qt-tb-l{i}"><div class="rte"><p>{l}</p></div></div>')
    rows.append(f'    <div class="fe b-qt-tb-r{i}"><div class="rte"><p>{r}</p></div></div>')
rows.append(f'    <div class="fe b-qt-tb-dend fe--top">{HR}</div>')
rows_html = "\n".join(rows)

qt_body = f'''<section class="sec t-white h-custom s-quy-trinh-0">
  {DIV(ZIG2)}
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-qt-title"><div class="rte"><div class="scaled"><h3 class="center">QUY TRÌNH GIA CÔNG</h3></div><div class="scaled"><h3 class="center">TỪ BẢN VẼ ĐẾN THÀNH PHẨM</h3></div></div></div>
    {NOTE_STOCK}
    <div class="fe b-qt-hero">{img("quy-trinh-hero.jpg",2000,1200,"Thợ hàn đang thi công chi tiết kim loại",eager=True)}</div>
    <div class="fe b-qt-sub"><div class="rte"><h4 class="center"><strong>Tám bước khép kín trong cùng một xưởng</strong></h4></div></div>
    <div class="fe b-qt-intro"><div class="rte"><p class="t-small">Chi tiết của khách hàng đi hết từ khâu nhận bản vẽ đến khi đóng kiện mà không phải rời khỏi xưởng. Nhờ vậy chúng tôi kiểm soát được kích thước ở từng công đoạn, giảm rủi ro trầy xước khi vận chuyển giữa các đơn vị và rút ngắn thời gian giao hàng.</p><p class="t-small">Với đơn hàng lặp lại, dưỡng gá và thông số sơn của lô đầu được lưu lại để những lô sau ra đúng cùng một kết quả.</p></div></div>
    </div>
  </div>
</section>

<section class="sec t-black-bold h-custom s-quy-trinh-1">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-qt-steps"><div class="rte"><h4><span class="c-accent"><strong>CÁC BƯỚC THỰC HIỆN</strong></span></h4>{steps_html}</div></div>
    <div class="fe b-qt-img1">{img("quy-trinh-02.jpg",1400,1050,"Đầu dao CNC đang gia công chi tiết")}</div>
    </div>
  </div>
</section>

<section class="sec t-white h-small s-quy-trinh-2">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-qt-qc"><div class="rte"><h4><strong>KIỂM TRA CHẤT LƯỢNG</strong></h4><p class="t-small">Chúng tôi không dồn việc kiểm tra vào cuối chuyền. Sau mỗi công đoạn, chi tiết được đối chiếu lại với bản vẽ trước khi chuyển bước — sai lệch phát hiện sớm thì sửa nhanh và không kéo theo cả lô hàng.</p><p class="t-small"><strong>Trước khi giao,</strong> lớp sơn được kiểm màu, độ dày và độ bám; số lượng được đếm lại theo phiếu giao hàng và bọc lót chống trầy xước.</p><p class="t-small"><strong>Nếu có sai sót từ phía xưởng,</strong> chúng tôi nhận làm lại chi tiết đó — quý khách vui lòng phản hồi kèm hình ảnh trong thời gian sớm nhất sau khi nhận hàng.</p></div></div>
    <div class="fe b-qt-img2">{img("quy-trinh-03.jpg",1200,900,"Công đoạn xử lý bề mặt trước khi sơn")}</div>
    <div class="fe b-qt-img3">{img("quy-trinh-04.jpg",1200,900,"Chi tiết cơ khí đặt trên bản vẽ kỹ thuật")}</div>
    </div>
  </div>
</section>

<section class="sec t-white h-small s-quy-trinh-3">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-qt-h3"><div class="rte"><h3 class="center"><strong>Hạng mục kiểm tra ở từng công đoạn</strong></h3></div></div>
    <div class="fe b-qt-hr fe--top">{HR}</div>
    <div class="fe b-qt-l1"><div class="rte"><p><strong>Trước gia công</strong></p><ul data-rte-list="default"><li><p>Đối chiếu bản vẽ và xác nhận dung sai</p></li><li><p>Kiểm tra vật tư đầu vào</p></li><li><p>Duyệt phương án pha phôi</p></li></ul></div></div>
    <div class="fe b-qt-l2"><div class="rte"><p><strong>Trong gia công</strong></p><ul data-rte-list="default"><li><p>Đo kích thước sau cắt và chấn</p></li><li><p>Kiểm mối hàn, độ vuông góc</p></li><li><p>Làm sạch bề mặt trước khi sơn</p></li></ul></div></div>
    <div class="fe b-qt-l3"><div class="rte"><p><strong>Trước khi giao</strong></p><ul data-rte-list="default"><li><p>Kiểm màu và độ dày lớp sơn</p></li><li><p>Thử độ bám của lớp phủ</p></li><li><p>Đếm số lượng, đóng gói</p></li></ul></div></div>
    </div>
  </div>
</section>

<section class="sec t-black-bold h-small s-quy-trinh-4">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-qt-tb-title"><div class="rte"><h3 class="center"><strong>PHẠM VI NHẬN GIA CÔNG</strong></h3></div></div>
    <div class="fe b-qt-tb-hl"><div class="rte"><p><strong>Hạng mục</strong></p></div></div>
    <div class="fe b-qt-tb-hr"><div class="rte"><p><strong>Phạm vi</strong></p></div></div>
{rows_html}
    </div>
  </div>
</section>

<section class="sec t-black-bold h-medium s-quy-trinh-5">
  {DIV(ZIG4)}
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-qt-cta"><div class="rte"><div class="scaled"><p class="center"><span class="c-accent"><strong>Gửi bản vẽ, nhận báo giá</strong></span></p></div><p class="center">Quý khách gửi bản vẽ hoặc hình ảnh chi tiết cần gia công, chúng tôi phản hồi phương án và giá trong giờ làm việc.</p><p class="center">Email: <a href="mailto:{EMAIL}">{EMAIL}</a></p></div></div>
    <div class="fe b-qt-cta-btn"><a class="btn" href="{P}lien-he/index.html">NHẬN BÁO GIÁ</a></div>
    </div>
  </div>
</section>'''
W("quy-trinh/index.html", page(P,"quy-trinh.css",
  "Quy trình gia công cơ khí &amp; sơn tĩnh điện — KỸ NGHỆ NGUYỄN MINH",
  "Tám bước gia công khép kín: nhận bản vẽ, pha phôi, cắt CNC, chấn đột, hàn, xử lý bề mặt, sơn tĩnh điện, kiểm tra và giao hàng. Kèm phạm vi nhận gia công và hạng mục kiểm tra chất lượng.",
  "DỊCH VỤ", qt_body))

# ═════════════════════════════════════════════════════════════════════ DỰ ÁN
GAL = [
 ("san-pham-01.jpg","Chi tiết máy gia công CNC","Thép · tiện – phay theo bản vẽ"),
 ("san-pham-02.jpg","Gá đỡ nhôm gia công chính xác","Nhôm · phay CNC"),
 ("san-pham-03.jpg","Mặt bích và chi tiết dạng đĩa","Thép · tiện CNC"),
 ("san-pham-04.jpg","Khung kết cấu thép","Thép hộp · hàn MIG · sơn tĩnh điện"),
 ("san-pham-05.jpg","Hàn kết cấu tại xưởng","Hàn MIG / TIG"),
 ("san-pham-06.jpg","Cụm thiết bị và tủ kỹ thuật","Tôn mạ kẽm · sơn tĩnh điện"),
 ("san-pham-07.jpg","Gia công chi tiết dạng ống","Thép · cắt – mài – hoàn thiện"),
 ("san-pham-08.jpg","Cắt tôn theo file DXF","Cắt CNC · lô sản xuất"),
 ("san-pham-09.jpg","Hoàn thiện bề mặt chi tiết","Mài, làm sạch trước khi sơn"),
]
gal = []
for i,(s,t,m) in enumerate(GAL,1):
    gal.append(f'    <div class="fe b-da-img{i}">{img(s,1100,825,t)}</div>')
    gal.append(f'    <div class="fe b-da-cap{i}"><div class="cap"><span class="cap__title">{t}</span><span class="cap__meta">{m}</span></div></div>')
gal_html = "\n".join(gal)

da_body = f'''<section class="sec t-white h-small s-du-an-0">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-da-h2"><div class="rte"><h2>SẢN PHẨM &amp; DỰ ÁN</h2></div></div>
    <div class="fe b-da-lead"><div class="rte"><p class="t-small">Một số hạng mục tiêu biểu chúng tôi nhận gia công: chi tiết máy, khung kết cấu, vỏ tủ thiết bị và các sản phẩm kim loại hoàn thiện bằng sơn tĩnh điện. Quý khách cần gia công hạng mục tương tự, vui lòng gửi bản vẽ hoặc hình ảnh để nhận báo giá.</p></div></div>
    </div>
  </div>
</section>

<section class="sec t-white h-custom s-du-an-1">
  <div class="wrap">
    <div class="fluid">
    {NOTE_STOCK}
{gal_html}
    </div>
  </div>
</section>

<section class="sec t-black-bold h-medium s-du-an-2">
  {DIV(ZIG4)}
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-da-cta"><div class="rte"><div class="scaled"><p class="center"><span class="c-accent"><strong>Bạn có bản vẽ cần gia công?</strong></span></p></div><p class="center">Gửi bản vẽ hoặc hình ảnh chi tiết, chúng tôi tư vấn vật liệu và báo giá trong giờ làm việc.</p><p class="center">Email: <a href="mailto:{EMAIL}">{EMAIL}</a></p></div></div>
    <div class="fe b-da-cta-btn"><a class="btn" href="{P}lien-he/index.html">NHẬN BÁO GIÁ</a></div>
    </div>
  </div>
</section>'''
W("du-an/index.html", page(P,"du-an.css",
  "Sản phẩm &amp; dự án đã thực hiện — KỸ NGHỆ NGUYỄN MINH",
  "Hình ảnh các hạng mục gia công cơ khí và sơn tĩnh điện tiêu biểu: chi tiết máy, khung kết cấu thép, vỏ tủ thiết bị và sản phẩm kim loại hoàn thiện.",
  "DỰ ÁN", da_body))

# ═════════════════════════════════════════════════════════════════════ LIÊN HỆ
MAPQ = "S%E1%BB%91%20110%20Khu%20ph%E1%BB%91%20Kh%C3%A1nh%20Long%2C%20T%C3%A2n%20Kh%C3%A1nh%2C%20B%C3%ACnh%20D%C6%B0%C6%A1ng"
info_rows = [
 ("Công ty", COMPANY),
 ("Địa chỉ", ADDR),
 ("Mã số thuế", MST),
 ("Email", f'<a href="mailto:{EMAIL}">{EMAIL}</a>'),
 ("Khu vực phục vụ", "Bình Dương · Thành phố Hồ Chí Minh · Đồng Nai"),
 ("Hạng mục nhận gia công", "Cắt CNC · chấn · đột · hàn kết cấu · tiện phay · sơn tĩnh điện"),
]
info_html = "".join(
 f'<div class="info__row"><span class="info__label">{k}</span><span class="info__value">{v}</span></div>'
 for k,v in info_rows)

lh_body = f'''<section class="sec t-bright-inverse h-custom s-lien-he-0">
  <div class="sec-bg">{img("lien-he-bg.jpg",1800,1200,"",eager=True)}<div class="sec-bg__overlay"></div></div>
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-lh-h2"><div class="rte"><h3><span class="c-accent"><strong>LIÊN HỆ &amp; YÊU CẦU BÁO GIÁ</strong></span></h3></div></div>
    <div class="fe b-lh-info"><div class="info">{info_html}</div></div>
    <div class="fe b-lh-card"><div class="shape" aria-hidden="true"></div></div>
    <div class="fe b-lh-form"><form class="form" novalidate>
        <div class="form__list">
          <div class="form__item">
            <span class="form__title">Thông tin liên hệ</span>
            <div class="form__row">
              <div class="form__field"><label class="form__label t-small" for="q-name">Họ và tên <span>(bắt buộc)</span></label><input id="q-name" name="name" type="text" autocomplete="name" required></div>
              <div class="form__field"><label class="form__label t-small" for="q-phone">Số điện thoại <span>(bắt buộc)</span></label><input id="q-phone" name="phone" type="text" autocomplete="tel" required></div>
            </div>
          </div>
          <div class="form__item"><div class="form__field"><label class="form__label t-small" for="q-company">Công ty</label><input id="q-company" name="company" type="text" autocomplete="organization"></div></div>
          <div class="form__item"><div class="form__field"><label class="form__label t-small" for="q-email">Email <span>(bắt buộc)</span></label><input id="q-email" name="email" type="email" autocomplete="email" required></div></div>
          <div class="form__item"><div class="form__field"><label class="form__label t-small" for="q-subject">Hạng mục cần gia công <span>(bắt buộc)</span></label><input id="q-subject" name="subject" type="text" required></div></div>
          <div class="form__item"><div class="form__field"><label class="form__label t-small" for="q-details">Nội dung yêu cầu <span>(bắt buộc)</span></label><textarea id="q-details" name="details" required></textarea></div></div>
          <div class="form__item form__item--file">
            <label class="form__label t-small" for="q-file">Đính kèm bản vẽ</label>
            <p class="form__hint">Gửi kèm bản vẽ hoặc hình ảnh chi tiết để chúng tôi báo giá chính xác hơn.</p>
            <label class="form__drop" for="q-file"><span class="form__plus" aria-hidden="true">+</span><span>Chọn tệp</span></label>
            <input id="q-file" name="file" type="file" class="form__fileinput">
          </div>
        </div>
        <div class="form__submit"><button class="btn" type="submit">GỬI YÊU CẦU</button></div>
        <p class="form__note t-small" role="status" hidden>Website đang ở dạng tĩnh, biểu mẫu chưa nối với máy chủ. Quý khách vui lòng gửi yêu cầu tới <a href="mailto:{EMAIL}">{EMAIL}</a>.</p>
      </form></div>
    </div>
  </div>
</section>

<section class="sec t-white h-small s-lien-he-1">
  <div class="wrap">
    <div class="fluid">
    <div class="fe b-lh-map-h4"><div class="rte"><h4>VỊ TRÍ XƯỞNG</h4></div></div>
    <div class="fe b-lh-map"><div class="map"><iframe title="Bản đồ vị trí xưởng Kỹ Nghệ Nguyễn Minh" src="https://www.google.com/maps?q={MAPQ}&amp;output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div></div>
    </div>
  </div>
</section>'''
W("lien-he/index.html", page(P,"lien-he.css",
  "Liên hệ &amp; yêu cầu báo giá — KỸ NGHỆ NGUYỄN MINH",
  f"Liên hệ Công ty TNHH Kỹ Nghệ Nguyễn Minh — {ADDR_S}. MST {MST}. Email {EMAIL}. Gửi bản vẽ để nhận báo giá gia công cơ khí và sơn tĩnh điện.",
  "", lh_body))
print("quy-trinh, du-an, lien-he")
